extends Control


var reactors = 0 
var reactor_cost = 10 
var reactor_production = 1

var auto_sellers = 0
var auto_seller_cost = 25
var auto_seller_speed = 5


var stored_energy = 0
var max_storage = 100

var credits = 0 


@onready var energy_label = $VBoxContainer/EnergyLabel
@onready var credits_label = $VBoxContainer/Credits
@onready var reactor_label = $VBoxContainer/reactor
@onready var auto_seller_label = $VBoxContainer/AutoSellerLabel


func _on_sell_energy_pressed() -> void:
	credits += stored_energy
	stored_energy = 0
	update_ui()


func _on_tick_timer_timeout() -> void:
	stored_energy += reactors * reactor_production
	
	#Maximale gespeicherte Energie
	if stored_energy > max_storage:
		stored_energy = max_storage	
		
	#Automatisches verkaufen von Energie
	var sold_energy = min(stored_energy, auto_sellers* auto_seller_speed)
	stored_energy -= sold_energy
	credits += sold_energy
	update_ui()


func update_ui():
	energy_label.text = "Stored Energy: " + str(stored_energy)
	credits_label.text = "Credits: " + str(credits)
	reactor_label.text = "Mini Reactors: " + str(reactors)
	auto_seller_label.text = "Autosellers:" + str(auto_sellers)

func _on_windmill_pressed() -> void:
	if credits >= reactor_cost:
		credits -= reactor_cost
		reactors += 1 
		update_ui()


func _on_button_pressed() -> void:
	stored_energy += 1
	update_ui()


func _on_buy_auto_seller_pressed() -> void:
	if credits >= auto_seller_cost:
		credits -= auto_seller_cost
		auto_sellers += 1
		update_ui()
